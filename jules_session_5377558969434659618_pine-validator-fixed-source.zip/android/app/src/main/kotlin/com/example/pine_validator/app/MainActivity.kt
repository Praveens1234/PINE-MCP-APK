package com.example.pine_validator.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
